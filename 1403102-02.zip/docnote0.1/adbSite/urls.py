from django.conf.urls import patterns, include, url
from django.contrib import admin
from books import views
from adbSite import settings
urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'adbSite.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    #url(r'^admin/', include(admin.site.urls)),
    
    url(r'^$',views.loginPage),
    url(r'^about/$',views.about),
    url(r'^register/$',views.register),
    url(r'^search/$',views.search),
    url(r'^index/$',views.index),
    url(r'^add/$',views.add),
    url(r'^modify/$',views.modify),
    url(r'^login/$',views.login),
    url(r'^logout/$',views.logout),
   	
   	 
    url(r'^site_medias/(?P<path>.*)$','django.views.static.serve',{'document_root':settings.STATICFILES_DIRS, 'show_indexes': True}),
)
