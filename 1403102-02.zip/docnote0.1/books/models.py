from django.db import models

# Create your models here.
class Contacts(models.Model):
	name = models.CharField(max_length=30)
	studentID = models.CharField(max_length=30)
	phone = models.CharField(max_length=30)
	email = models.EmailField()
	qq = models.CharField(max_length=30)
	address = models.CharField(max_length=100)
	birthday = models.CharField(max_length=30)
	owner = models.CharField(max_length=50)
	
	def __unicode__(self):
		return self.name
		
class Users(models.Model):
	username = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	email = models.EmailField()
	
	def __unicode__(self):
		return self.username



