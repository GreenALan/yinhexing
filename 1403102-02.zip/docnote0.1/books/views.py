from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from books.models import Contacts , Users
# Create your views here.
def getUsername(request):
	try:
		username = request.session['user']
		if username == None:
			return None
		else:
			return username
	except:
		return None

def about(request):
	username=getUsername(request)
	if username==None:
		return render_to_response("login.html",{'notLogin_error':True})
	return render_to_response("about.html",{'username':username})
	

def search(request):
	username=getUsername(request)
	if username==None:
		return render_to_response("login.html",{'notLogin_error':True})
		
	
	keyword=request.GET['keyword']
	if keyword=='':
		contactList = Contacts.objects.filter(owner=request.session['user'])
		return render_to_response("index.html",{'contactList':contactList,'isSearch':False,'username':username})
	else: 
		contactList = Contacts.objects.filter(name__icontains=keyword,owner=request.session['user'])
		return render_to_response("index.html",{'contactList':contactList,'isSearch':True,'keyword':keyword,'username':username})

def index(request):
	username=getUsername(request)
	if username==None:
		return render_to_response("login.html",{'notLogin_error':True})

	contactList = Contacts.objects.filter(owner=request.session['user'])
	return render_to_response("index.html",{'contactList':contactList,'isSearch':False,'username':username})

def clean(con):
	if con.name=='':
		con.name='---'
	if con.studentID=='':
		con.studentID='---'
	if con.phone=='':
		con.phone='---'
	if con.email=='':
		con.email='---'
	if con.qq=='':
		con.qq='---'
	if con.address=='':
		con.address='---'
	if con.birthday=='':
		con.birthday='---'
	if con.owner=='':
		con.owner='---'
	return con
		

def add(request):
	username=getUsername(request)
	if username==None:
		return render_to_response("login.html",{'notLogin_error':True})

	tempContact = Contacts(
		name=request.POST['name'],
		studentID=request.POST['studentID'],
		phone=request.POST['phone'],
		email=request.POST['email'],
		qq=request.POST['qq'],
		address=request.POST['address'],
		birthday=request.POST['birthday'],
		owner=request.session['user']
	)
	clean(tempContact).save()
	return HttpResponseRedirect("/index/")


	
def modify(request):
	username=getUsername(request)
	if username==None:
		return render_to_response("login.html",{'notLogin_error':True})

	if request.POST['action']=='modify':
		person = Contacts.objects.get(id=request.POST['ID'],owner=request.session['user'])
		person.name=request.POST['name']
		person.studentID=request.POST['studentID']
		person.phone=request.POST['phone']
		person.email=request.POST['email']
		person.qq=request.POST['qq']
		person.address=request.POST['address']
		person.birthday=request.POST['birthday']
		person.owner=request.session['user']
		clean(person).save()
	else:#delete
		person = Contacts.objects.get(id=request.POST['ID'],owner=request.session['user'])
		person.delete()
	return HttpResponseRedirect("/index/")
	
	
def loginPage(request):
	return render_to_response("login.html")

def register(request):	
	name=request.POST['reg_username']
	try:
		user = Users.objects.get(username=name,)
	except Users.DoesNotExist:
		tempUser = Users(
			username=request.POST['reg_username'],
			password=request.POST['reg_password'],
			email=request.POST['reg_email']
		)
		tempUser.save()
		return render_to_response("login.html",{'reg_success':True})
	else:
		return render_to_response("login.html",{'userExist_error':True,'wrongUsername':name})

def login(request):
	try:
		password = Users.objects.get(username=request.POST['username']).password
		if password==request.POST['password']:
			request.session['user']=Users.objects.get(username=request.POST['username']).username
			return HttpResponseRedirect("/index/")
		else:
			return render_to_response("login.html",{'worngPass_error':True})
	except Users.DoesNotExist:
		return render_to_response("login.html",{'noUser_error':True,'wrongUsername':request.POST['username']})
	
def logout(request):
	request.session['user'] = None
	return render_to_response("login.html",{'logOut_success':True})
	
